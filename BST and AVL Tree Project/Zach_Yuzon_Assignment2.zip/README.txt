ZACH YUZON
CSCI 335
PROFESSOR STAMOS
MARCH 4, 2018
-----------------------
Part 1: Which parts of your assignment were completed.

All parts of the assignment is completed in my program.

-----------------------
Part 2: Bugs that you encountered.

The main bugs I encountered were errors in calling function as I forgot to include “a_tree.” before calling the function.

Another bug I encountered was not having my output values exactly match the expected output given in the assignment. Some of them are around 1-5 numbers off.

------------------------
Part 3: Complete instructions of how to run your program(s).

1. Make sure that all files are within the same folder as each other.
2. Open the terminal and “cd” into the folder containing the source files.
3. Input “make all” into the terminal.
4. Input one of these commands into the terminal:
./query_trees rebase210.txt BST < input_part2a.txt
./query_tree rebase210.txt AVL < input_part2a.txt
./test_tree rebase210.txt sequences.txt BST
./test_tree rebase210.txt sequences.txt AVL
5. The file should run after that input.

------------------------
Part 4: The input file (if any) and the output files (if any).

The input files are called:
input_part2a.txt
rebase210.txt
sequences.txt

The output files are called:
output_part2a.txt
output_part2b.txt
